package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.cg.dto.User_Master;
import com.cg.util.DBUtil;

public class LoginDaoImpl implements LoginDao{

	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet re=null;

	public LoginDaoImpl() {

		con = DBUtil.getConnection();
	}
	@Override
	public String usertype(User_Master um) {
               String user = null;
               String id=um.getUserId();
               String pass=um.getUserPassword();
		try {
					
		pst=con.prepareStatement(QueryMapper.LOGIN);
		
			  pst.setString(1,id);
			  pst.setString(2,pass);
				re=pst.executeQuery();
				
				if(re.next())
				{
					user=re.getString("UserType");
					
				}else
					System.out.println("Invalid UserId or Password");//return e;
		} catch (Exception e2) {
			
			e2.printStackTrace();
		}
		return user;
		
	}

}
