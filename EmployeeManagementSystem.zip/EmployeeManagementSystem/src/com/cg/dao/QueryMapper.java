package com.cg.dao;

public interface QueryMapper {

	public static final String LOGIN="SELECT * FROM User_Master WHERE UserId=? AND UserPassword=?";
}
