package com.cg.dao;

import com.cg.dto.User_Master;

public interface LoginDao {
	
	public String usertype(User_Master um);

}
