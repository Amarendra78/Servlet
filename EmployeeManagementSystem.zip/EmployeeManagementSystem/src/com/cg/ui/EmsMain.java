package com.cg.ui;

import java.util.Scanner;

import com.cg.dto.User_Master;
import com.cg.service.LoginService;
import com.cg.service.LoginServiceImpl;

public class EmsMain {

	static Scanner sc=new Scanner(System.in);
	static LoginService empService=null;
	public static void main(String[] args) {
		
		
		empService=new LoginServiceImpl();
		
		 System.out.println("******************Welcome to Employee Management System***************");
		 System.out.println("Enter userId....");
	     String id=sc.next();
	     System.out.println("Enter Password....");
	     String pass=sc.next();
	     User_Master um=new User_Master(id,pass);
	     String choice= usertype(um);
	     
	     
       
       }
	
	private static String usertype(User_Master um) {
		String ans=empService.usertype(um);
		return ans;
	}
	
	
}
