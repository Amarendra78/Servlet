package com.cg.dto;

public class User_Master {

	String UserId;
	String UserName;
	String UserPassword;
	String UserType;
	
	public User_Master() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public User_Master(String userId, String userPassword) {
		super();
	this.UserId = userId;
	this.UserPassword = userPassword;
	}


	public User_Master(String userId, String userName, String userPassword,
			String userType) {
		super();
		this.UserId = userId;
		this.UserName = userName;
		this.UserPassword = userPassword;
		this.UserType = userType;
	}
	
		

	public String getUserId() {
		return UserId;
	}

	public void setUserId(String userId) {
		UserId = userId;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getUserPassword() {
		return UserPassword;
	}

	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}

	public String getUserType() {
		return UserType;
	}

	public void setUserType(String userType) {
		UserType = userType;
	}

	@Override
	public String toString() {
		return "User_Master [UserId=" + UserId + ", UserName=" + UserName
				+ ", UserPassword=" + UserPassword + ", UserType=" + UserType
				+ "]";
	}
	
	
	
}
