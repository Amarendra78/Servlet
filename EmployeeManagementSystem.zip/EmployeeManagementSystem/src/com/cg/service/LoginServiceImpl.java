package com.cg.service;
import com.cg.dao.LoginDao;
import com.cg.dao.LoginDaoImpl;
import com.cg.dto.User_Master;

public class LoginServiceImpl implements LoginService {

	
	LoginDao dao;
    
	public LoginServiceImpl() {
		
		dao=new LoginDaoImpl();
	}
	@Override
	public String usertype(User_Master um) {
		// TODO Auto-generated method stub
		return dao.usertype(um);
	}

}
