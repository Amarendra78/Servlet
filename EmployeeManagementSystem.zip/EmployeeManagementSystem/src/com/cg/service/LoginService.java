package com.cg.service;

import com.cg.dto.User_Master;

public interface LoginService {
	
	public String usertype(User_Master um);

}
