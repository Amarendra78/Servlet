package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String qstr=request.getParameter("action");
		if("login".equals(qstr))
		{
			RequestDispatcher dispatch=request.getRequestDispatcher("login.jsp");
					dispatch.forward(request,response);
		}else if("register".equals(qstr))
		{
			RequestDispatcher dispatch=request.getRequestDispatcher("register.jsp");
			dispatch.forward(request,response);
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String qStr=request.getParameter("action");
		if("loginUser".equals(qStr))
		{
			String user=request.getParameter("uname");
			String passwd=request.getParameter("pwd");
			if("CG".equals(user) && "123".equals(passwd))
			{
				response.sendRedirect("success.jsp");
			}
			else
				response.sendError(404,"Invalid Credentials");
		}
		else if("registerUser".equals(qStr))
		{
			String user=request.getParameter("uName");
			String addr=request.getParameter("addr");
			String passwd=request.getParameter("pwd");
			ServletContext context=this.getServletContext();
			context.setAttribute("user",user);
			context.setAttribute("addr",addr);
			context.setAttribute("passwd",passwd);
			//context.setAttribute();
			response.sendRedirect("user.jsp");
		}
	}

}
