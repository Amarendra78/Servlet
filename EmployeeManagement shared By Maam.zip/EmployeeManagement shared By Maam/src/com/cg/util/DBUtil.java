package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {

	static Connection con;
	
	static
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String passwd = "Capgemini123";
			con = DriverManager.getConnection(url,user,passwd);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	public static Connection getConnection()
	{
		return con;
	}
}
