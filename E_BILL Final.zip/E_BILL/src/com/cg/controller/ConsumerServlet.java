package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumer;

import com.cg.service.BillDetailsService;
import com.cg.service.BillDetailsServiceImpl;
import com.cg.service.ConsumerService;
import com.cg.service.ConsumerServiceImpl;



@WebServlet("/ConsumerServlet")
public class ConsumerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    ConsumerService service; 
    BillDetailsService bservice;
    public ConsumerServlet() {
    	service = new ConsumerServiceImpl();
        // TODO Auto-generated constructor stub
    	bservice=new BillDetailsServiceImpl();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		HttpSession session = request.getSession(true);
		String qStr = request.getParameter("action");
		
		if("displayAll".equals(qStr))
		{
			ArrayList<Consumer> list = service.getAllConsumers();
			session.setAttribute("conslist", list);
			RequestDispatcher dispatch = request.getRequestDispatcher("showConsumerList.jsp");
			dispatch.forward(request, response);
			
		}else if("displayByNum".equals(qStr))
		{
			RequestDispatcher dispatch = request.getRequestDispatcher("searchConsumer.jsp");
			dispatch.forward(request, response);			
		}
		else if("billInfo".equals(qStr))
		{
			String consNum = request.getParameter("consumer_num");
			int Num = Integer.parseInt(consNum);
			session.setAttribute("consnum",Num);
			ArrayList<BillDetails> bill = bservice.getAllBills(Num);
			if(bill.size()==0)
			{
				RequestDispatcher dispatch = request.getRequestDispatcher("error.jsp");
				dispatch.forward(request, response);
			}
			else{
			session.setAttribute("billByNum", bill);
			RequestDispatcher dispatch = request.getRequestDispatcher("showBills.jsp");
			dispatch.forward(request, response);			
		}}
		else if("newBill".equals(qStr))
		{
		String consNum = request.getParameter("consumer_num");
			int Num = Integer.parseInt(consNum);
			session.setAttribute("billNum", Num);
			RequestDispatcher dispatch = request.getRequestDispatcher("newbillInfo.jsp");
			dispatch.forward(request, response);			
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		HttpSession session = request.getSession(false);
		String qStr = request.getParameter("action");
		if("searchByNum".equals(qStr))
		{
			
			String consNum = request.getParameter("num");
			int Num = Integer.parseInt(consNum);
			Consumer cons = service.getConsumerByNum(Num);
			session.setAttribute("consByNum", cons);
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("showConsumer.jsp");
			dispatch.forward(request, response);
		}else if("insertBill".equals(qStr))
		{
			String Num = request.getParameter("consNum");
			int num = Integer.parseInt(Num);
			String la = request.getParameter("last");
			 float last = Float.parseFloat(la);
		    String cu = request.getParameter("current");
		    float current = Float.parseFloat(cu);
		    
		    float unitConsumed=current-last;
		    BillDetails b=new BillDetails(num,unitConsumed,current);	    
		    BillDetails ref = bservice.calcBill(b);
		    
		    session.setAttribute("calcbill", ref);
		    	RequestDispatcher dispatch =
		    			request.getRequestDispatcher("newBillCalc.jsp");
		    	dispatch.forward(request, response);
		    }
		}
		
	}


