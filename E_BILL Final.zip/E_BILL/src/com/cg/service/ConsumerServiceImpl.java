package com.cg.service;
import java.util.ArrayList;

import com.cg.dao.ConsumerDao;
import com.cg.dao.ConsumerDaoImpl;
import com.cg.dto.Consumer;

public class ConsumerServiceImpl implements ConsumerService {

	ConsumerDao dao;
	
	public ConsumerServiceImpl()
	{
		dao=new ConsumerDaoImpl();
	}
	@Override
	public Consumer getConsumerByNum(int consumer_num) {
		
		return dao.getConsumerByNum( consumer_num);
	}

	@Override
	public ArrayList<Consumer> getAllConsumers() {
		
		return dao.getAllConsumers();
	}
	
	

}
