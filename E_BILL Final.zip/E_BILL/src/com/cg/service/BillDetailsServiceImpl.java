package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.BillDetailsDao;
import com.cg.dao.BillDetailsDaoImpl;
import com.cg.dto.BillDetails;

public class BillDetailsServiceImpl implements BillDetailsService
{
     BillDetailsDao dao;
     
	public BillDetailsServiceImpl() {
		
		dao=new BillDetailsDaoImpl();
	}

	@Override
	public ArrayList<BillDetails> getAllBills(int consumer_num) {
		// TODO Auto-generated method stub
		return dao.getAllBills(consumer_num);
	}

	@Override
	public BillDetails calcBill(BillDetails b) {
		// TODO Auto-generated method stub
		return dao.calcBill(b);
	}

}
