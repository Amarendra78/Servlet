package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumer;



public interface ConsumerService {
	
	public Consumer getConsumerByNum(int consumer_num);	
	public ArrayList<Consumer> getAllConsumers();
	
	
}
