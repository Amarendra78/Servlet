package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.BillDetails;


public interface BillDetailsService {

	public ArrayList<BillDetails> getAllBills(int consumer_num);

	public BillDetails calcBill(BillDetails b);
	
}
