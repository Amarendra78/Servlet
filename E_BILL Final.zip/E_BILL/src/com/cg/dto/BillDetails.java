package com.cg.dto;

import java.sql.Date;
import java.time.LocalDate;

public class BillDetails {
	int bill_num;
	int consumer_num;
	float cur_reading;
	float unitConsumed;
	float netAmount;
	Date bill_date;
	public BillDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public BillDetails(int consumer_num,float unitConsumed,float current)
	{
		this.consumer_num = consumer_num;
		this.unitConsumed = unitConsumed;
		this.cur_reading=current;
    	}
	public BillDetails(int bill_num, int consumer_num, float cur_reading,
			float unitConsumed, float netAmount, Date bill_date) {
		super();
		this.bill_num = bill_num;
		this.consumer_num = consumer_num;
		this.cur_reading = cur_reading;
		this.unitConsumed = unitConsumed;
		this.netAmount = netAmount;
		this.bill_date = bill_date;
	}
	@Override
	public String toString() {
		return "BillDetails [bill_num=" + bill_num + ", consumer_num="
				+ consumer_num + ", cur_reading=" + cur_reading
				+ ", unitConsumed=" + unitConsumed + ", netAmount=" + netAmount
				+ ", bill_date=" + bill_date + "]";
	}
	public int getBill_num() {
		return bill_num;
	}
	public void setBill_num(int bill_num) {
		this.bill_num = bill_num;
	}
	public int getConsumer_num() {
		return consumer_num;
	}
	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}
	public float getCur_reading() {
		return cur_reading;
	}
	public void setCur_reading(float cur_reading) {
		this.cur_reading = cur_reading;
	}
	public float getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(float unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public float getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(float netAmount) {
		this.netAmount = netAmount;
	}
	public Date getBill_date() {
		return bill_date;
	}
	public void setBill_date(Date bill_date) {
		this.bill_date = bill_date;
	}

}
