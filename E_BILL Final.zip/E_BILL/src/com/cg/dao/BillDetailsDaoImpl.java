package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;

import com.cg.dto.BillDetails;

import com.cg.util.DBUtil;

public class BillDetailsDaoImpl implements BillDetailsDao {

	Connection con;

	public BillDetailsDaoImpl() {

		con = DBUtil.getConnection();
	}

	@Override
	public ArrayList<BillDetails> getAllBills(int consumer_num) {
		// TODO Auto-generated method stub

		String qry = "SELECT * FROM BillDetails where consumer_num=?";
		ArrayList<BillDetails> list = new ArrayList<BillDetails>();
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, consumer_num);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				int bill_num = rs.getInt(1);
				int consumer_num1 = rs.getInt(2);
				float cur_reading = rs.getFloat(3);
				float unitConsumed = rs.getFloat(4);
				float netAmount = rs.getFloat(5);
				Date date = rs.getDate(6);
				BillDetails b = new BillDetails(bill_num, consumer_num1,
						cur_reading, unitConsumed, netAmount, date);
				list.add(b);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;

	}

	@Override
	public BillDetails calcBill(BillDetails b) {

		BillDetails b1 = null;
		float unit = b.getUnitConsumed();
		float amount = (float) (1.15 * (unit) + 100);
		float cur_reading = b.getCur_reading();
		b.setNetAmount(amount);
		

		String qry = "INSERT INTO BillDetails VALUES(seq_bill_num.nextval,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, b.getConsumer_num());
			pstmt.setFloat(2, cur_reading);
			pstmt.setFloat(3, unit);
			pstmt.setFloat(4, b.getNetAmount());
			pstmt.setDate(5, Date.valueOf(LocalDate.now()));
			int row = pstmt.executeUpdate();
			if (row > 0) {				
				 b1=b;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return b1;

	}

}
