package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Consumer;

public interface ConsumerDao {

public Consumer getConsumerByNum(int consumer_num);
	
	public ArrayList<Consumer> getAllConsumers();
}
