package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.BillDetails;

public interface BillDetailsDao {
	
	public ArrayList<BillDetails> getAllBills(int consumer_num);

	public BillDetails calcBill(BillDetails b);
}
