package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.dto.Consumer;
import com.cg.util.DBUtil;

public class ConsumerDaoImpl implements ConsumerDao {

	Connection con;
	
	public ConsumerDaoImpl()
	{
		con = DBUtil.getConnection();
		
	}
	@Override
	public Consumer getConsumerByNum(int consumer_num) {
		
		
		
		Consumer ref = null;
		String qry = "SELECT * FROM Consumers WHERE consumer_num=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1,consumer_num);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				int num = rs.getInt(1);
				String name = rs.getString(2);
				String addr = rs.getString(3);
				ref = new Consumer(num,name,addr);
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ref;
	}

	@Override
	public ArrayList<Consumer> getAllConsumers() {
		// TODO Auto-generated method stub
		String qry = "SELECT * FROM Consumers";
		ArrayList<Consumer>list = new ArrayList<Consumer>();
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String addr = rs.getString(3);
				Consumer cons = new Consumer(id,name,addr);
				list.add(cons);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}

}
